module.exports.productValidation = require("./product.validation");
module.exports.userValidation = require("./user.validation");