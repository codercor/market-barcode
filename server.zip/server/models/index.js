module.exports.category = require("./category.model")
module.exports.product = require("./product.model")
module.exports.user = require("./user.model")